package contact;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import contact.ContactClass;

class ContactClassTest {

	
	//setting test criteria
	@Test
	void testContactClass() {
		//Arrange
		ContactClass contactClass = new ContactClass("John", "Smith", "1234567890", "8881234321", "123 Home St Nowhere AA 12345" );
		assertTrue(contactClass.getFirstName().equals("John"));
		assertTrue(contactClass.getLastName().equals("Smith"));
		assertTrue(contactClass.getId().equals("1234567890"));
		assertTrue(contactClass.getPhoneNumber().equals("8881234321"));
		assertTrue(contactClass.getAddress().equals("123 Home St Nowhere AA 12345"));
	}
		//Act & Assert
	@Test
	void testContactIdIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new ContactClass("John", "Smith", null, "8881234321", "123 Home St Nowhere AA 12345");
		});		}	

	@Test
	void testContactIdToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new ContactClass("John", "Smith", "12345000001", "8881234321", "123 Home St Nowhere AA 12345");
		});		

       		 // ID shorter than 10 characters
         	 try {new ContactClass("John", "Smith", "12345", "8881234321", "123 Home St Nowhere AA 12345");
            	 // code that is expected to not throw an exception
        	} catch (Exception e) {
            fail("Exception was thrown");
       	 }

        	// ID equals 10 characters
         	try {new ContactClass("John", "Smith", "1234567890", "8881234321", "123 Home St Nowhere AA 12345");
         	// code that is expected to not throw an exception
     	 } catch (Exception e) {
          fail("Exception was thrown");}
      }
	

	
	@Test
	void testContactFirstNameToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new ContactClass("This first name is too long", "Smith", "1234567890", "8881234321", "123 Home St Nowhere AA 12345");
		});		

	 	// FirstName shorter than 10 characters
         	 try {new ContactClass("John", "Smith", "12345", "8881234321", "123 Home St Nowhere AA 12345");
            	 // code that is expected to not throw an exception
        	} catch (Exception e) {
            fail("Exception was thrown"); 
       	 }

        	// FirstName equals 10 characters
         	try {new ContactClass("John is 1!", "Smith", "1234567890", "8881234321", "123 Home St Nowhere AA 12345");
         	// code that is expected to not throw an exception
     	 } catch (Exception e) {
          fail("Exception was thrown");}
      }
	
	@Test
	void testContactFirstNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new ContactClass(null, "Smith", "1234567890", "8881234321", "123 Home St Nowhere AA 12345");
		});		}

	@Test
	void testContactLastNameToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new ContactClass("John", "Smith is a cool name", "12345", "8881234321", "123 Home St Nowhere AA 12345");
		});		

 	// LastName shorter than 10 characters
         	 try {new ContactClass("John", "Smith", "12345", "8881234321", "123 Home St Nowhere AA 12345");
            	 // code that is expected to not throw an exception
        	} catch (Exception e) {
            fail("Exception was thrown");
       	 }

        	// FirstName equals 10 characters
         	try {new ContactClass("John is 1!", "Smith is1!", "1234567890", "8881234321", "123 Home St Nowhere AA 12345");
         	// code that is expected to not throw an exception
     	 } catch (Exception e) {
          fail("Exception was thrown");}
      }
	
	@Test
	void testContactLastNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new ContactClass("John", null, "1234567890", "8881234321", "123 Home St Nowhere AA 12345");
		});		}
	

	@Test
	void testContactPhoneNumerToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new ContactClass("John", "Smith", "1234567890", "888123432100", "123 Home St Nowhere AA 12345");
		});		}
	
	@Test
	void testContactPhoneNumberToShort() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new ContactClass("John", "Smith", "1234567890", "888", "123 Home St Nowhere AA 12345");
		});		}
	
	
	@Test
	void testContactPhoneNumberIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new ContactClass("John" , "Smith", "1234567890", null, "123 Home St Nowhere AA 12345");
		});		}
	
	@Test
	void testContactAddressToLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new ContactClass("John", "Smith", "1234567890", "8881234321", "123 Home St Nowhere AA 123451221");
		});		
	
 		// Address shorter than 10 characters
         	 try {new ContactClass("John", "Smith", "12345", "8881234321", "123 Home");
            	 // code that is expected to not throw an exception
        	} catch (Exception e) {
            fail("Exception was thrown"); 
       	 }

        	// Address equals 10 characters
         	try {new ContactClass("John is 1!", "Smith", "1234567890", "8881234321", "123 Hme St");
         	// code that is expected to not throw an exception
     	 } catch (Exception e) {
          fail("Exception was thrown");}
      }

	@Test
	void testContactAddressIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new ContactClass("John" , "Smith", "1234567890", "8881234321", null);
		});		}
	
	
}


