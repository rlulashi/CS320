package contact;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    private ContactService contactService;

    @BeforeEach
    public void setUp() {
        contactService = new ContactService();
    }

    @Test
    @DisplayName("Add Contact with Unique ID")
    public void testAddContactWithUniqueID() {
        ContactClass contact1 = new ContactClass("1", "John", "Smith", "1234567890", "123 Home St");
        ContactClass contact2 = new ContactClass("2", "Jane", "Doe", "9876543210", "456 Oak St");
       
        contactService.addContact(contact1);
        contactService.addContact(contact2);
    }
       
    @Test
    @DisplayName("Add Contact with Duplicate ID - Expect IllegalArgumentException")
    public void testAddContactWithDuplicateID() {
        ContactClass contact1 = new ContactClass("1", "John", "Smith", "1234567890", "123 Home St");
        ContactClass contact2 = new ContactClass("1", "Jane", "Doe", "9876543210", "456 Oak St");

        //Act
        contactService.addContact(contact1);
        contactService.addContact(contact2);
        } 
 
   

    @Test
    @DisplayName("Update Contact Fields by ID")
    public void testUpdateContactField() {
        // Create and add the initial contact
        ContactClass contact = new ContactClass("1", "John", "Jones", "1234567890", "123 Home St");
        contactService.addContact(contact);
 
        // Update each field and capture the updated contact
        contactService.updateContactField("1", "firstName", "UpdatedFirstName");
        contact = contactService.getContactById("1");

        assertEquals("UpdatedFirstName", contact.getFirstName());

        contactService.updateContactField("1", "lastName", "UpdatedLastName");
        contact = contactService.getContactById("1");

        assertEquals("UpdatedLastName", contact.getLastName());

        contactService.updateContactField("1", "phoneNumber", "9876543210");
        contact = contactService.getContactById("1");

        assertEquals("9876543210", contact.getPhoneNumber());

        contactService.updateContactField("1", "address", "UpdatedAddress");
        contact = contactService.getContactById("1");

        assertEquals("UpdatedAddress", contact.getAddress());
    }
    
    @Test
    @DisplayName("Delete Contact by ID")
    public void testDeleteContact() {
        // Arrange
        ContactClass contact = new ContactClass("1", "John", "Jones", "1234567890", "123 Home St");
        contactService.addContact(contact);

        // Verify that the contact exists before deletion
        assertNotNull(contactService.getContactById("1"));

        // Act
        contactService.deleteContact("1");
 
        // Assert
        // Use assertThrows to handle the exception and check its message
        assertThrows(IllegalArgumentException.class, () -> contactService.getContactById("1"),
                "Contact with ID 1 not found for deletion");
    }
}