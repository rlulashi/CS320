package contact;

import java.util.HashMap;
import java.util.Map;


public class ContactService {
    private Map<String, ContactClass> contacts;

     public ContactService() {
        this.contacts = new HashMap<>();
    }

    public void addContact(ContactClass contact) {
  	if (contact == null) {
            throw new IllegalArgumentException("Contact cannot be null");
        }      
  	if (contacts.containsKey(contact.getId())) {
            throw new IllegalArgumentException("Contact with the same ID already exists");
        }

        contacts.put(contact.getId(), contact); 
    }
    
    public ContactClass getContactById(String contactId) {
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact with ID " + contactId + " not found");
        }
        return contacts.get(contactId);
        
    }

    public void updateContactField(String contactId, String fieldName, String newValue) {
        if (!contacts.containsKey(contactId)) {
           throw new IllegalArgumentException("Contact with ID " + contactId + " not found");
      }

        ContactClass contact = contacts.get(contactId);
    
        switch (fieldName) {
            case "firstName": 
                contact.setFirstName(newValue);
                break; 
            case "lastName":
                contact.setLastName(newValue);
                break; 
            case "phoneNumber":
                contact.setPhoneNumber(newValue);
                break;
            case "address": 
                contact.setAddress(newValue);
                break;
            default:
                throw new IllegalArgumentException("Invalid field name: " + fieldName);
        }
    }
    
     
    public void deleteContact(String contactId) {
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact with ID " + contactId + " not found for deletion");
        }
        contacts.remove(contactId);
    }


   // Additional method to retrieve appointments map for testing
   public Map<String, ContactClass> getContacts() {
    	return contacts;
   }
}
 