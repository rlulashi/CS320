package contact;

import java.util.Objects;

//Constructor class
public class ContactClass {
    private static final int MAX_ID_LENGTH = 10;
    private static final int MAX_FIRSTNAME_LENGTH = 10;
    private static final int MAX_LASTNAME_LENGTH = 10;
    private static final int MAX_ADDRESS_LENGTH = 30;
    private static final int MAX_PHONENUMBER_LENGTH = 10;


//Initialize variables
	private String id;
	private String firstName;
	private String lastName;
	private String phoneNumber;
	private String address;
	
	
	
	//adding Illegal Argument Exception for conditions
	public ContactClass(String firstName, String lastName, String id, String phoneNumber, String address) {
		if (id == null || id.length() > MAX_ID_LENGTH) {
			throw new IllegalArgumentException("Invalid ID");
		
		}
				
		if (firstName == null || firstName.length() > MAX_FIRSTNAME_LENGTH) {
			throw new IllegalArgumentException("Invalid name");
		
		}
			
		
		if (lastName == null || lastName.length() > MAX_LASTNAME_LENGTH) {
			throw new IllegalArgumentException("Invalid name");
		
		}
		
			
		if (phoneNumber == null || phoneNumber.length() > MAX_PHONENUMBER_LENGTH) {
			throw new IllegalArgumentException("Invalid number");
		
		}
	
		if (phoneNumber == null || phoneNumber.length() < MAX_PHONENUMBER_LENGTH) {
			throw new IllegalArgumentException("Invalid number");
		
		}
		
		if (phoneNumber == null || phoneNumber.length() != MAX_PHONENUMBER_LENGTH) {
			throw new IllegalArgumentException("Invalid number");
		
		}
			
		if (address == null || address.length() > MAX_ADDRESS_LENGTH) {
			throw new IllegalArgumentException("Invalid address");
		
		}


		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.address = address;

	}
	
	   @Override
	    public boolean equals(Object obj) {
	        if (this == obj) return true;
	        if (obj == null || getClass() != obj.getClass()) return false;
	        ContactClass contact = (ContactClass) obj;
	        return id.equals(contact.id);
	    }
	   @Override
	    public int hashCode() {
	        return Objects.hash(id);
	    }

	public String getId () {
		return id;
	}

	public String getFirstName () {
		return firstName;
	}

	public String getLastName () {
		return lastName;
	}
	
	public String getPhoneNumber () {
		return phoneNumber;
	}

	public String getAddress () {
		return address;
	}
	
	
	
	public void setFirstName(String firstName) {
	    this.firstName = firstName;
	}

	public void setLastName(String lastName) {
	    this.lastName = lastName;
	}

	public void setPhoneNumber(String phoneNumber) {
	    this.phoneNumber = phoneNumber;
	}

	public void setAddress(String address) {
	    this.address = address;
	}

}
	
